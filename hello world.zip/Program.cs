﻿using System;
public class MyClass{
    public static void Main()
    {
        var name="kousar";
        Console.WriteLine($"Hello this is {name}");
        Console.ReadKey();
    }
}
